# Pixelated: House Edge entry (candidate c11)

- Team: Pixelated (solo)
- Round: main
- Season ID: 5fffdc4d0c700bbf61c3f911
- Environment: `python` image (Python 3.13) plus `requirements.txt`: lightgbm==4.7.0, narwhals==2.28.0, numpy==2.5.4, scipy==1.18.1 (exact pins; narwhals and scipy are lightgbm dependencies)

## Recreate the forecast

Run from this folder:

```sh
python predict.py --data /data --out /output/submission.csv
```

- What it does: loads the pre-trained models in `model/`, builds strictly causal features from `/data/test` histories (only ticks before each cutoff), and writes the five probabilities per query. Prediction only; no training, no network.
- Model files: `model/win.txt` (LightGBM win-probability model), `model/size.txt` (LightGBM win-size model), `model/meta.json` (payout tables, feature list), `pixelated/lp_prior.npy` (per-type rule prior used by the filter features).
- Method: `p_0 = 1 - w`, other payouts = `w x mix`, where `w` comes from a LightGBM model trained self-supervised on train + validation histories (never test). Features: each machine's recent and long-run lag effects, recent win rates for pairs of earlier ticks, and the forecast and confidence of a learned-prior rule filter (448 lag-pair rules; prior, emission levels and switch settings estimated from train histories only). `mix` is projected onto the machine type's two payout tables. The payout tables are read from the validation targets, and training rows are weighted per condition using the validation targets and reference forecasts.
- Randomness: none at prediction time; output is deterministic in the tested environment.
- Training command (not needed to recreate the forecast): `python scripts/train_v1.py --name c11-final --loss brier --final` in the development repository, seed 7.

## Local check

From the organizer kit folder (the checker and `public/` are not part of this ZIP):

```sh
python check_submission.py <path/to/submission.csv> --data public
```

- Checker result: valid (1536 queries, main, test).
- Fresh-folder reproduction (Linux, organizer-style): the code was unpacked from this ZIP into a clean `python:3.13` container (Python 3.13.18; only `requirements.txt` installed, pip freeze = the four pins). It ran the `reproduce.json` command with `/submission` and `/data` read-only, `--network none --memory 16g --cpus 2 --cpuset-cpus 0,1` (2 visible cores). It took about 21-24 seconds, with peak container memory (cgroup `memory.peak`) about 6.8 GiB. Reruns are byte-identical to each other on Linux.
- Cross-platform: the CSV built on Windows 11 (Python 3.13.7, same pins) differs from the Linux one only in the last floating-point digits (max difference 2.8e-17 after normalisation, within the 1e-8 tolerance). Windows reruns are byte-identical to each other (fresh venv, 2 logical CPUs: about 43-71 seconds, about 6.5 GiB sampled).
